/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("stylescombo","zh",{label:"樣式",panelTitle:"Formatting Styles",panelTitle1:"塊級元素樣式",panelTitle2:"內聯元素樣式",panelTitle3:"物件元素樣式"});