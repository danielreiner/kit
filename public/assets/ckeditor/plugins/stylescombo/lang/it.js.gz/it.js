/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("stylescombo","it",{label:"Stile",panelTitle:"Stili di formattazione",panelTitle1:"Stili per blocchi",panelTitle2:"Stili in linea",panelTitle3:"Stili per oggetti"});