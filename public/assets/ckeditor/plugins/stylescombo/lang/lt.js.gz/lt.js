/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("stylescombo","lt",{label:"Stilius",panelTitle:"Stilių formatavimas",panelTitle1:"Blokų stiliai",panelTitle2:"Vidiniai stiliai",panelTitle3:"Objektų stiliai"});