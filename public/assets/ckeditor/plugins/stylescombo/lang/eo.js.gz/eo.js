/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("stylescombo","eo",{label:"Stiloj",panelTitle:"Stiloj pri enpaĝigo",panelTitle1:"Stiloj de blokoj",panelTitle2:"Enliniaj Stiloj",panelTitle3:"Stiloj de objektoj"});