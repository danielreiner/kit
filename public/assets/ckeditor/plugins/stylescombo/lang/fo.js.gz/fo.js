/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("stylescombo","fo",{label:"Typografi",panelTitle:"Formatterings stílir",panelTitle1:"Blokk stílir",panelTitle2:"Inline stílir",panelTitle3:"Object stílir"});